import { MapPin, Navigation, Zap, DollarSign, Clock, Shield } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

export default function Features() {
  const features = [
    {
      icon: MapPin,
      title: "Find Parking Anywhere",
      description: "Discover available parking spots on streets and in private lots across Brisbane. Real-time availability at your fingertips.",
      image: "https://images.unsplash.com/photo-1650805180952-9d3d1430c5eb?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzdHJlZXQlMjBwYXJraW5nJTIwY2FyfGVufDF8fHx8MTc3NDIyODk1OXww&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      icon: Navigation,
      title: "Smart Transit Connections",
      description: "Parked far from your destination? We'll suggest the best public transport options to get you there quickly.",
      image: "https://images.unsplash.com/flagged/photo-1580993435882-63a124c05aca?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwdWJsaWMlMjB0cmFuc3BvcnQlMjBidXMlMjB0cmFpbnxlbnwxfHx8fDE3NzQyMjg5NjB8MA&ixlib=rb-4.1.0&q=80&w=1080"
    },
    {
      icon: Zap,
      title: "Lightning Fast",
      description: "Super simple interface designed for speed. Find parking and plan your journey in seconds, not minutes.",
      image: "https://images.unsplash.com/photo-1609921133942-9e485ac26bc8?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2JpbGUlMjBhcHAlMjBwaG9uZSUyMGhhbmR8ZW58MXx8fHwxNzc0MjI4OTYwfDA&ixlib=rb-4.1.0&q=80&w=1080"
    }
  ];

  const benefits = [
    {
      icon: DollarSign,
      title: "Save Money",
      description: "Find affordable street parking and optimize your transport costs"
    },
    {
      icon: Clock,
      title: "Save Time",
      description: "No more circling blocks looking for parking spots"
    },
    {
      icon: Shield,
      title: "Stress-Free",
      description: "Navigate Brisbane with confidence and ease"
    }
  ];

  return (
    <div className="py-24 bg-background">
      <div className="max-w-7xl mx-auto px-6">
        {/* Main Features */}
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl mb-6">
            Everything You Need
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Park & Ride combines the best of parking search and public transport planning in one seamless experience.
          </p>
        </div>

        <div className="space-y-24 mb-32">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            const isEven = index % 2 === 0;

            return (
              <div
                key={index}
                className={`flex flex-col ${isEven ? 'lg:flex-row' : 'lg:flex-row-reverse'} items-center gap-12 lg:gap-16`}
              >
                <div className="flex-1">
                  <div className="bg-primary text-primary-foreground w-14 h-14 rounded-2xl flex items-center justify-center mb-6">
                    <Icon className="w-7 h-7" />
                  </div>
                  <h3 className="text-3xl mb-4">{feature.title}</h3>
                  <p className="text-lg text-muted-foreground leading-relaxed">
                    {feature.description}
                  </p>
                </div>
                <div className="flex-1">
                  <div className="rounded-3xl overflow-hidden shadow-2xl">
                    <ImageWithFallback
                      src={feature.image}
                      alt={feature.title}
                      className="w-full h-[400px] object-cover"
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Benefits Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div key={index} className="bg-card border border-border rounded-2xl p-8 text-center hover:shadow-lg transition-shadow">
                <div className="bg-accent w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-8 h-8 text-accent-foreground" />
                </div>
                <h4 className="mb-3">{benefit.title}</h4>
                <p className="text-muted-foreground">{benefit.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
