import { Car, MapPin, Mail, Twitter, Instagram, Linkedin } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-primary-foreground py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="bg-white text-primary w-10 h-10 rounded-xl flex items-center justify-center">
                <Car className="w-6 h-6" />
              </div>
              <span className="text-2xl">Park & Ride</span>
            </div>
            <p className="text-primary-foreground/80 mb-6 max-w-md">
              Making parking and public transport seamless for Brisbane. Join us as we revolutionize urban mobility.
            </p>
            <div className="flex items-center gap-2 text-primary-foreground/80">
              <MapPin className="w-4 h-4" />
              <span>Launching in Brisbane, Australia</span>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="mb-4">Quick Links</h4>
            <ul className="space-y-3 text-primary-foreground/80">
              <li>
                <a href="#" className="hover:text-primary-foreground transition-colors">
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition-colors">
                  How It Works
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition-colors">
                  Features
                </a>
              </li>
              <li>
                <a href="#" className="hover:text-primary-foreground transition-colors">
                  FAQ
                </a>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="mb-4">Get in Touch</h4>
            <ul className="space-y-3 text-primary-foreground/80">
              <li>
                <a href="mailto:hello@parkandride.app" className="hover:text-primary-foreground transition-colors flex items-center gap-2">
                  <Mail className="w-4 h-4" />
                  hello@parkandride.app
                </a>
              </li>
              <li className="pt-4">
                <div className="flex gap-3">
                  <a href="#" className="bg-white/10 w-9 h-9 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors">
                    <Twitter className="w-4 h-4" />
                  </a>
                  <a href="#" className="bg-white/10 w-9 h-9 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors">
                    <Instagram className="w-4 h-4" />
                  </a>
                  <a href="#" className="bg-white/10 w-9 h-9 rounded-lg flex items-center justify-center hover:bg-white/20 transition-colors">
                    <Linkedin className="w-4 h-4" />
                  </a>
                </div>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-4 text-primary-foreground/70 text-sm">
          <div>
            © {currentYear} Park & Ride. All rights reserved.
          </div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-primary-foreground transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="hover:text-primary-foreground transition-colors">
              Terms of Service
            </a>
            <a href="#" className="hover:text-primary-foreground transition-colors">
              Contact
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
