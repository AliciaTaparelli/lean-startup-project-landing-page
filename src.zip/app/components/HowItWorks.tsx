import { Search, Car, Bus } from 'lucide-react';

export default function HowItWorks() {
  const steps = [
    {
      icon: Search,
      number: "01",
      title: "Enter Your Destination",
      description: "Tell us where you're heading in Brisbane and we'll find the best parking options nearby."
    },
    {
      icon: Car,
      number: "02",
      title: "Choose Your Spot",
      description: "Browse available street parking or private lots with real-time availability and pricing."
    },
    {
      icon: Bus,
      number: "03",
      title: "Get Transit Options",
      description: "If your parking is far from your destination, we'll suggest the fastest public transport route."
    }
  ];

  return (
    <div className="py-24 bg-muted/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-20">
          <h2 className="text-4xl md:text-5xl mb-6">
            How It Works
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Three simple steps to stress-free parking and travel in Brisbane
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={index} className="relative">
                {/* Connector Line */}
                {index < steps.length - 1 && (
                  <div className="hidden md:block absolute top-20 left-[60%] w-[80%] h-0.5 bg-border z-0"></div>
                )}

                <div className="relative z-10 bg-card border border-border rounded-3xl p-8 hover:shadow-xl transition-shadow">
                  <div className="bg-primary text-primary-foreground w-20 h-20 rounded-2xl flex items-center justify-center mb-6">
                    <Icon className="w-10 h-10" />
                  </div>

                  <div className="text-6xl opacity-10 absolute top-4 right-6">
                    {step.number}
                  </div>

                  <h3 className="text-2xl mb-4">{step.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {step.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Visual Example */}
        <div className="mt-20 bg-gradient-to-br from-primary/5 to-primary/10 rounded-3xl p-12 text-center">
          <div className="max-w-3xl mx-auto">
            <h3 className="text-3xl mb-4">
              The Perfect Journey
            </h3>
            <p className="text-lg text-muted-foreground mb-8">
              Park on a quiet street 5 minutes from the city center, save $15 on parking, and catch a quick bus to your meeting. That's the Park & Ride difference.
            </p>
            <div className="flex flex-wrap justify-center gap-6">
              <div className="bg-background border border-border rounded-xl px-6 py-3">
                <div className="text-sm text-muted-foreground">Average Savings</div>
                <div className="text-2xl">$12/day</div>
              </div>
              <div className="bg-background border border-border rounded-xl px-6 py-3">
                <div className="text-sm text-muted-foreground">Time Saved</div>
                <div className="text-2xl">15 min</div>
              </div>
              <div className="bg-background border border-border rounded-xl px-6 py-3">
                <div className="text-sm text-muted-foreground">Stress Level</div>
                <div className="text-2xl">Zero</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
