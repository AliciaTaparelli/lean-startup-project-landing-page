import { ImageWithFallback } from './figma/ImageWithFallback';
import { MapPin, Zap } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1616069629754-9b20b61f10a0?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwyfHxwYXJraW5nJTIwYnJpc2JhbmUlMjBjaXR5fGVufDF8fHx8MTc3NDIyODk1M3ww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Brisbane city skyline"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/80"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-6 py-20 text-center">
        <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2 mb-8">
          <MapPin className="w-4 h-4 text-white" />
          <span className="text-white/90">Launching in Brisbane, Australia</span>
        </div>

        <h1 className="text-5xl md:text-7xl text-white mb-6 max-w-4xl mx-auto">
          Park Smart. Ride Easy.
        </h1>

        <p className="text-xl md:text-2xl text-white/90 mb-12 max-w-3xl mx-auto">
          The simplest way to find parking and connect to public transport. Coming soon to Brisbane.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <button className="bg-white text-primary px-8 py-4 rounded-full hover:bg-white/90 transition-all shadow-lg hover:shadow-xl flex items-center gap-2">
            <Zap className="w-5 h-5" />
            Join the Waitlist
          </button>
          <button className="bg-white/10 backdrop-blur-sm border border-white/30 text-white px-8 py-4 rounded-full hover:bg-white/20 transition-all">
            Learn More
          </button>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-20 max-w-4xl mx-auto">
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
            <div className="text-4xl text-white mb-2">10,000+</div>
            <div className="text-white/70">Parking Spots</div>
          </div>
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
            <div className="text-4xl text-white mb-2">&lt;30s</div>
            <div className="text-white/70">Average Search Time</div>
          </div>
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
            <div className="text-4xl text-white mb-2">100%</div>
            <div className="text-white/70">Free to Use</div>
          </div>
        </div>
      </div>
    </div>
  );
}
