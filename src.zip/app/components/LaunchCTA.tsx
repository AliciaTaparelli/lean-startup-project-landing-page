import { ImageWithFallback } from './figma/ImageWithFallback';
import { Bell, Mail, CheckCircle2 } from 'lucide-react';
import { useState } from 'react';

export default function LaunchCTA() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    setTimeout(() => {
      setEmail('');
      setSubmitted(false);
    }, 3000);
  };

  return (
    <div className="relative py-24 overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1656501380598-aac6c7e24024?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwYXJraW5nJTIwYnJpc2JhbmUlMjBjaXR5fGVufDF8fHx8MTc3NDIyODk1M3ww&ixlib=rb-4.1.0&q=80&w=1080"
          alt="Brisbane river and city"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-primary/95 via-primary/90 to-primary/95"></div>
      </div>

      <div className="relative z-10 max-w-4xl mx-auto px-6 text-center">
        <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2 mb-8">
          <Bell className="w-4 h-4 text-white" />
          <span className="text-white/90">Brisbane Pilot Launch - Coming April 2026</span>
        </div>

        <h2 className="text-4xl md:text-6xl text-white mb-6">
          Be First to Experience Park & Ride
        </h2>

        <p className="text-xl text-white/90 mb-12 max-w-2xl mx-auto">
          Join our exclusive waitlist and get early access when we launch in Brisbane. Plus, receive special perks for early adopters.
        </p>

        {/* Email Form */}
        {!submitted ? (
          <form onSubmit={handleSubmit} className="max-w-md mx-auto mb-12">
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="flex-1 relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  required
                  className="w-full pl-12 pr-4 py-4 rounded-full bg-white text-foreground border-2 border-transparent focus:border-white/50 outline-none"
                />
              </div>
              <button
                type="submit"
                className="bg-white text-primary px-8 py-4 rounded-full hover:bg-white/90 transition-all shadow-lg whitespace-nowrap"
              >
                Join Waitlist
              </button>
            </div>
          </form>
        ) : (
          <div className="max-w-md mx-auto mb-12 bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
            <div className="flex items-center justify-center gap-3 text-white">
              <CheckCircle2 className="w-6 h-6" />
              <span className="text-lg">You're on the list! Check your email.</span>
            </div>
          </div>
        )}

        {/* Benefits */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
            <div className="text-3xl mb-2">🎁</div>
            <div className="text-white">Early Access</div>
            <div className="text-white/70 text-sm mt-1">Be the first to try</div>
          </div>
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
            <div className="text-3xl mb-2">⭐</div>
            <div className="text-white">Exclusive Perks</div>
            <div className="text-white/70 text-sm mt-1">Special launch offers</div>
          </div>
          <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl p-6">
            <div className="text-3xl mb-2">💬</div>
            <div className="text-white">Shape the Future</div>
            <div className="text-white/70 text-sm mt-1">Your feedback matters</div>
          </div>
        </div>
      </div>
    </div>
  );
}
