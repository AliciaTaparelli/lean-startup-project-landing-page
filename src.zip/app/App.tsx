import { ImageWithFallback } from './components/figma/ImageWithFallback';
import Hero from './components/Hero';
import Features from './components/Features';
import HowItWorks from './components/HowItWorks';
import LaunchCTA from './components/LaunchCTA';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="size-full min-h-screen bg-background">
      <Hero />
      <Features />
      <HowItWorks />
      <LaunchCTA />
      <Footer />
    </div>
  );
}
